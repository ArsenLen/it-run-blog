import React from 'react';

const Link = (props) => {
    return (
        <a>
           ссылка {props.num}
        </a>
    );
};

export default Link;