import React from 'react';
import Link from '../Link/Link'

const Nav = () => {
    return (
    <nav>
        <Link num="1" />  
        <Link num="2" />  
        <Link num="3" />  
    </nav>
    );
};

export default Nav;