import React from 'react';
import {Link, Route} from 'react-router-dom'

const Post = (props) => {
    return (
        <div className="post">
            <h5>{props.title}</h5>
            <p>{props.descr}</p>
            <p>{props.date}</p>
        </div>
    );
};

export default Post;


// data.results.name.first