import React from 'react';

const SinglePost = () => {
    return (
        <div>
            hello
        </div>
    );
};

export default SinglePost;