import React, {useEffect, useState} from 'react';
import Post from '../Post/Post'
import axios from 'axios'
// отфильтровать массив который содержит посты и сразу промапить. filter().map(el => <Post> )
// filter() Для какого массива применить метод фильтр. posts.filter()

// вывести количество статей и новостей
const Main = (props) => {

  const [title, setTitle] = useState("")
  const [date, setDate] = useState("")
  const [descr, setDescr] = useState("")
  const [category, setCategory] = useState("1")
  const [likes, setLikes] = useState(0)

  const handleSubmit = (e) => {
  e.preventDefault()
  axios.post('http://localhost:3004/posts', {
    date,
    postTitle: title,
    postDescr : descr,
    category
  })
  setTitle("")
  setDate("")
  setDescr("")
  }

  const handleLikes = () => {
    setLikes(likes + 1)
  }

  return (
      <main>
      <form className="postForm" onSubmit={handleSubmit}>
        <div className="formElem">
            <label htmlFor="title">Введите заголовок поста: </label>
            <input type="text" name="title" value={title} onChange={e => setTitle(e.target.value)} /> 
        </div>
        <div className="formElem">
          <label htmlFor="title">Введите дату: </label> 
          <input type="text" name="date" value={date} onChange={e => setDate(e.target.value)} />  
        </div>
        <div className="formElem">
          <label htmlFor="descr">Введите описание: </label> 
          <textarea rows="10" cols="45"
           name="descr" value={descr} onChange={e => setDescr(e.target.value)}>
          </textarea>  
        </div>
        <div className="formElem">
          <select name="" id="" value={category} onChange={e => setCategory(e.target.value)}>
            <option value="1">Новость</option>
            <option value="2">Статья</option>
          </select>
        </div>
        <input className="postSubmit" type="submit" value="Опубликовать"/>
      </form> 
      {props.posts.filter(post => post.category == 1).map(post => {
          return (
            <Post key={post.id} descr={post.postDescr} title={post.postTitle} date={post.date} id={post.id}/>
          )
        })} 
      <div>
        количество лайков = {likes}   
      </div>  
      <button onClick={handleLikes}>лайкнуть</button>

      </main>
  );
};

export default Main;