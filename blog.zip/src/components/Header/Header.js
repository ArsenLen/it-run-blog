import React from 'react';
import logo from '../../logo.svg';
import Nav from '../Nav/Nav';

const Header = () => {
  return (
    <header>
        <img src={logo} alt="" />
        <Nav/>
    </header>
  );
};

export default Header;
// rsc