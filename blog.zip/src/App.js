import "./App.css";
import { useState, useEffect } from "react";
import Header from "./components/Header/Header";
import Main from "./components/Main/Main";
import Footer from "./components/Footer/Footer";
import Sidebar from "./components/Sidebar/Sidebar";
import SinglePost from "./components/SinglePost/SinglePost";
import axios from 'axios'
import { Routes, Route, Link } from "react-router-dom";

const fetchData = () => {
  return axios.get('http://localhost:3004/posts')
    .then(response => response.data)
}

const App = () => {

  const [posts, setPosts] = useState([])

  useEffect(() => {
      fetchData().then(posts => setPosts(posts))
    }, [])

  return (
    <div className="App">
      <Header />
      <div className="content-wrapper">
        <Main posts={posts} />
        <Sidebar posts={posts} />
      </div>
      <Footer />
    </div>
  );
};

export default App;
// Создать footer
